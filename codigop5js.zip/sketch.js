// Variables globales 
// Se crean las variables que controlan el funcionamiento general del proyecto

// Controla las pantallas del proyecto 
// 0 = Inicio
// 1 = Experiencia 
// 2 = Final 
let estado = 0; 

// Colores iniciales del fondo y las figuras 
let colorFondo = 0;
let colorFigura = 255; 

// Guarda las figuras que se dibujaran en la experiencia 
// 1 = Círculos
// 2 = Cuadrados 
// 3 = Rectángulos 
let tipoFigura = 1; 

// Variable para alternar entre fondo oscuro y fondo claro mediante un clic 
let fondoClaro = false; 

// Variable donde se almacena el archivo de sonido
let sonido; 

// Se cargan los recursos externos para que esten disponibles cuando sea necesario 
function preload(){

  // Archivo de sonido 
  sonido = loadSound("sonido.mp3");
}

function setup(){

  // Se crea el lienzo 
  createCanvas(800,800);

  // Centra el texto horizontal y verticalmente
  textAlign(CENTER,CENTER);
  
}

function draw(){

  // Pantalla de inicio
  if(estado == 0){

    pantallaInicio();
  }

  // Pantalla de experiencia
  else if(estado == 1){

    pantallaExperiencia();
  }

  //pantalla final
  else if(estado == 2){

    pantallaFinal();
  }
  
}

// Pantalla de inicio muestra la introducción del proyecto y las instrucciones para comenzar 

function pantallaInicio(){

  // Fondo negro 
  background(0);

  // Tamaño fijo de los circulos 
  let tamaño = 20;

  // Color blanco para figuras 
  fill(255);
  stroke(255);

  // Genera una grilla de circulos utilizando dos ciclos for (filas y columnas)

for(let y=250; y<700; y+=50){

  for(let x=80; x<800; x+=80){

    ellipse(x,y,tamaño,tamaño);
  }
}

  // Configuracion del texto 
  
  noStroke();
  fill(255);

  textSize(50);
  text("PERCEPCIÓN CINÉTICA", width/2,90);

  textSize(25); 
  text("La percepción cinética transforma figuras estáticas", width/2,145);
  text("en una sensación de movimiento gracias a tu interacción.", width/2,170);

  textSize(30);

  // Instrucción para comenzar 
  text("Presiona ENTER para comenzar la experiencia", width/2,730);
  
}

// Pantalla de experiencia es la parte interactiva del proyecto 

function pantallaExperiencia(){

   // Fondo dinámico
  background(colorFondo);

   // Convierte la posición horizontal del mouse en el tamaño base de las figuras
  let tamaño = map(mouseX,0,width,20,50);

   // Filas
  for(let y=50;y<800;y+=40){

    // Columnas
    for(let x=50;x<800;x+=80){

      // Dibuja una figura en cada posición
      dibujarFigura(x,y,tamaño);

    }

  }

    // Muestra instrucciones para el usuario
  noStroke();

  fill(colorFigura);

  textAlign(LEFT);

  textSize(18);

  text("1 = Círculos",20,25);

  text("2 = Cuadrados",20,50);

  text("3 = Rectángulos",20,75);

  text("Click = Invertir colores",20,110);

  text("ESPACIO = Finalizar experiencia",20,135);
  
}

// Dibujar figura es una funcion creada para no repetir codigo 
// Dibuja una figura segun el tipo seleccionado

function dibujarFigura(x,y,tamaño){

  // Genera una variación aleatoria para que cada figura sea diferente
  let variacion = random(-10,30);

  fill(colorFigura);

  stroke(colorFigura);

  let tamañoFinal;

  // Si el mouse está en la mitad inferior, las figuras aumentan su tamaño
  if(mouseY > height/2){

    tamañoFinal = tamaño + variacion;

  }

   // Si el mouse está arriba, las figuras son más pequeñas
  else{

    tamañoFinal = tamaño/2 + variacion;

  }

  // Dibuja un círculo
  if(tipoFigura == 1){

    ellipse(x,y,tamañoFinal,tamañoFinal);

  }

  // Dibuja un cuadrado
  else if(tipoFigura == 2){

    rectMode(CENTER);

    square(x,y,tamañoFinal);

  }

  // Dibuja un rectángulo
  else{

    rectMode(CENTER);

    rect(x,y,tamañoFinal*1.5,tamañoFinal*0.7);

  }

}

// Pantalla final cierra la experiencia y permite volver al inicio 

function pantallaFinal(){

  background(0);

  fill(255);
  stroke(255);

  // Grilla final de círculos
  for(let y=240;y<650;y+=50){

    for(let x=80;x<800;x+=80){

      ellipse(x,y,20,20);

    }

  }

   noStroke();

  fill(255);

  textAlign(CENTER,CENTER);

  textSize(40);

  text("FIN DE LA EXPERIENCIA",width/2,100);

  textSize(22);

  text("La percepción del movimiento",width/2,150);

  text("fue generada por tu interacción.",width/2,185);

  textSize(24);

  text("ENTER para volver",width/2,700);

}

// Detecta cuando el usuario toca una tecla y ejecuta diferentes acciones 

function keyPressed(){

  // Inicio -> Experiencia
  if(estado == 0 && keyCode === ENTER){

    estado = 1;

  }

  // Experiencia -> Pantalla Final
  else if(estado == 1 && key == " "){

    estado = 2;

  }

  // Pantalla Final -> Inicio
  else if(estado == 2 && keyCode === ENTER){

    estado = 0;

  }

// Permite cambiar el tipo de figura y reproducir un sonido cuando cambia el tipo de figura 
  
  // Cambiar a círculos
  if(estado == 1 && key == "1"){

    tipoFigura = 1;

    if(!sonido.isPlaying()){
      sonido.play();
    }

  }

  // Cambiar a cuadrados
  if(estado == 1 && key == "2"){

    tipoFigura = 2;

    if(!sonido.isPlaying()){
      sonido.play();
    }

  }

  // Cambiar a rectángulos
  if(estado == 1 && key == "3"){

    tipoFigura = 3;

    if(!sonido.isPlaying()){
      sonido.play();
    }

  }

}


// Detecta un clic en el mouse e invierte los colores del proyecto


function mousePressed(){

  if(estado == 1){
    
// Cambia entre verdadero y falso 
    fondoClaro = !fondoClaro;
    
// Fondo blanco y figuras negras 
    if(fondoClaro){

      colorFondo = 255;
      colorFigura = 0;

    }

  // Fondo negro y figuras blancas 
    else{

      colorFondo = 0;
      colorFigura = 255;

    }

  }

}